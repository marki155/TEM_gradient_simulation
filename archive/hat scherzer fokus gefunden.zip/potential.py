import torch
import torch.nn as nn
import torch.nn.functional as F

from torch.nn.utils.rnn import pad_sequence


class DifferentiablePotential(nn.Module):
    def __init__(self, init_positions, init_intensities, shape, pixel_size_nm, wavelength_nm, device):
        super().__init__()
        #self.slices_V = [v.to(device) for v in slices_V]  # Liste komplexer Slices (H,W)
        self.pixel_size_m = pixel_size_nm
        self.wavelength_m = wavelength_nm
        self.device = device

        self.H, self.W = shape

        self.positions_method = "graphen_shift"
        self.intensity_classes = "vacancies" # "free", "vacancies", "classes"

        self.blur_sigma_ = 1.#nn.Parameter(torch.tensor(1., dtype=torch.float32, device=device), requires_grad=True)


        self._IDX = {"Gr": 0, "S1": 1, "W": 2, "S2": 3}
        self.N_l = len(init_positions)

        self.initialize_positions_parameters(init_positions)
        self.initialize_intensities_parameters(init_intensities)


    def initialize_positions_parameters(self, init_positions):
        if self.positions_method == "graphen_shift":
            graphen_shift = torch.tensor([0.0, 0.0], dtype=torch.float32, device=self.device)
            self.register_buffer("init_positions_Gr", torch.tensor(init_positions[self._IDX["Gr"]],
                                                                   dtype=torch.float32, device=self.device))
            self.positions_ = nn.ParameterList()
            for i in range(self.N_l):
                if i == self._IDX["Gr"]:
                    self.positions_.append(graphen_shift)
                else:
                    self.positions_.append(
                        nn.Parameter(torch.tensor(init_positions[i], dtype=torch.float32, device=self.device)))
        elif self.positions_method == "free":
            self.positions_ = nn.ParameterList(
                [torch.tensor(pos, dtype=torch.float32, device=self.device) for pos in init_positions])


    def initialize_intensities_parameters(self, init_intensities):


        if self.intensity_classes == "free":
            self.intensities_ = nn.ParameterList(
                [torch.tensor(I, dtype=torch.float32, device=self.device) for I in init_intensities])
        elif self.intensity_classes == "free_ws2":
            self.register_buffer("init_intensities_Gr", torch.tensor(init_intensities[self._IDX["Gr"]],
                                                                   dtype=torch.float32, device=self.device))
            self.intensities_ = nn.ParameterList(
                [torch.tensor(I, dtype=torch.float32, device=self.device) for I in init_intensities[1:]])
        elif self.intensity_classes == "vacancies":
            self.register_buffer("init_intensities_Gr", torch.tensor(init_intensities[self._IDX["Gr"]],
                                                                     dtype=torch.float32, device=self.device))
            #self.init_intensities = [torch.tensor(I, dtype=torch.float32, device=self.device) for I in init_intensities]
            # self.init_intensities = init_intensities
            # self.register_buffer("init_intensities", torch.tensor(init_intensities, dtype=torch.float32))
            self.vacanciesS1 = nn.Parameter(
                torch.ones(init_intensities[1].shape, dtype=torch.float32, device=self.device))
            self.vacanciesW = nn.Parameter(
                torch.ones(init_intensities[2].shape, dtype=torch.float32, device=self.device))
            self.vacanciesS2 = nn.Parameter(
                torch.ones(init_intensities[3].shape, dtype=torch.float32, device=self.device))
            #vacancies_list = [self.vacanciesS1, self.vacanciesW, self.vacanciesS2]

            #self.vacancies_tensor = pad_sequence(vacancies_list, batch_first=True)



        elif self.intensity_classes == "classes":
            self.classes = torch.nn.Parameter(torch.tensor([0.0, 16., 32., 74.], dtype=torch.float32, device=self.device))
            K = len(self.classes)
            N = self.positions.shape[0]
            self.intensities_ = torch.nn.Parameter(torch.rand(N, K))
        elif self.intensity_classes == "fixed":
            self.intensities_ = [torch.tensor(I, dtype=torch.float32, device=self.device) for I in init_intensities]
        else:

            raise ValueError("Unknown intensity class type")


    def get_positions(self):
        if self.positions_method == "graphen_shift":
            ret_positions = []
            for i in range(self.N_l):
                if i == self._IDX["Gr"]:
                    ret_positions.append(self.init_positions_Gr + self.positions_[self._IDX["Gr"]])
                else:
                    ret_positions.append(self.positions_[i])
            return ret_positions
        elif self.positions_method == "free":
            return self.positions_


    def get_intensities(self):
        if self.intensity_classes == "classes":
            # Softmax → Gewichtung über Klassen
            weights = F.softmax(self.intensities_, dim=1)  # shape (N, K)
            q = torch.sum(weights * self.classes, dim=1)  # gewichteter Mittelwert
            ret_intensities = q.unsqueeze(1)  # shape (N, 1)
            return ret_intensities
        elif self.intensity_classes == "free":
            return self.intensities_
        elif self.intensity_classes == "free_ws2":
            ret_intensities = [self.init_intensities_Gr]
            for i in range(len(self.intensities_)):
                ret_intensities.append(self.intensities_[i])
            return ret_intensities
        elif self.intensity_classes == "vacancies":
            return [self.init_intensities_Gr,
                    self.vacanciesS1.sigmoid() * 16.,
                    self.vacanciesW.sigmoid() * 74.,
                    self.vacanciesS2.sigmoid() * 16.
                    ]
        elif self.intensity_classes == "fixed":
            return self.intensities_


    def aux_loss(self):

        if self.intensity_classes == "classes":
            weights = F.softmax(self.intensities_, dim=1)
            entropy = -torch.sum(weights * torch.log(weights + 1e-8), dim=1).mean()
        elif self.intensity_classes == "free":
            entropy = 0.0
        elif self.intensity_classes == "vacancies":
            entropies = []
            ps = [self.vacanciesS1.sigmoid(),
                    self.vacanciesW.sigmoid(),
                    self.vacanciesS2.sigmoid()
                    ]
            for i in range(1, len(ps)):
               p = ps[i]
               entropy = -(p * torch.log(p + 1e-8) + (1-p) * torch.log(1-p + 1e-8)).mean()
               entropies.append(entropy)
            entropy = torch.mean(torch.stack(entropies))
        else:
            entropy = 0.0
        return entropy


    def forward(self, _):

        potential_list = []
        positions = self.get_positions()
        intensities = self.get_intensities()

        for i in range(self.N_l):
            rho_i = self.create_rho(positions[i], intensities[i])
            # rho_i = self.simulation.calc_rho(self.positions[i], torch.abs(self.intensities[i]).unsqueeze(1))
            potential_i = self.potential_2d_fft_nm(rho_i, device=self.device)
            potential_list.append(potential_i)

        return potential_list, self.aux_loss()





    def create_rho(self, pxpositions, intensities, multiplier=1.0):
        # pxpositions: (N, 2) Tensor
        # intensities: (N,) Tensor

        intensities = intensities.unsqueeze(1)  # (N, 1) Tensor

        rho = torch.zeros((self.W, self.H))

        # potential.fill_(self.background)  # Torch-Äquivalent

        py, px = pxpositions[:, 0], pxpositions[:, 1]

        # offset = int(self.canvas_size / self.kernelsize)
        offset = 0

        # Integer-Anteile
        # ix = torch.clamp(px.floor().to(torch.int64), min=0, max=self.shape[0] + self.canvas_size - 2)
        # iy = torch.clamp(py.floor().to(torch.int64), min=0, max=self.shape[1] + self.canvas_size - 2)

        ix = torch.clamp(px.floor().to(torch.int64), min=0, max=self.H - 2)
        iy = torch.clamp(py.floor().to(torch.int64), min=0, max=self.W - 2)

        # Bruchteile
        fx = px - ix
        fy = py - iy

        # Pixelgewichte
        w00 = torch.matmul((1 - fx), (1 - fy)) * intensities * multiplier
        w10 = torch.matmul(fx, (1 - fy)) * intensities* multiplier
        w11 = torch.matmul(fx, fy) * intensities* multiplier
        w01 = torch.matmul((1 - fx), fy) * intensities* multiplier

        # Indizes für alle vier Nachbarn
        idx00 = (offset + iy, offset + ix)
        idx10 = (offset + iy, offset + ix + 1)
        idx11 = (offset + iy + 1, offset + ix + 1)
        idx01 = (offset + iy + 1, offset + ix)

        # In-place Akkumulation wie np.add.at
        rho.index_put_(idx00, w00[:idx00[0].shape[0], 0], accumulate=True)
        rho.index_put_(idx10, w10[:idx10[0].shape[0], 0], accumulate=True)
        rho.index_put_(idx11, w11[:idx11[0].shape[0], 0], accumulate=True)
        rho.index_put_(idx01, w01[:idx01[0].shape[0], 0], accumulate=True)

        return torch.abs(rho)

    def potential_2d_nm(self, rho, sigma=0.1, epsilon0_nm=8.854e-21, device=None):
        """
        Berechnet geglättetes 2D-Potential aus Delta-Peaks (nm-Einheiten)

        rho: 2D-Tensor [ny,nx] in Vielfachen von e
        spacing: Pixelgröße in nm
        sigma: Glättungs-Gauss in nm
        epsilon0_nm: Permittivität in F/nm
        """
        e = 1.602e-19
        rho = rho.to(device, dtype=torch.float32)
        ny, nx = (self.W, self.H)
        spacing = self.pixel_size_m

        # Gaussian-Kernel
        s_pix = max(1, int(6 * sigma / spacing))
        if s_pix % 2 == 0: s_pix += 1
        coords = torch.arange(s_pix, device=device) - s_pix // 2
        Y, X = torch.meshgrid(coords, coords, indexing='ij')
        R2 = (X * spacing) ** 2 + (Y * spacing) ** 2
        G_kernel = torch.exp(-R2 / (2 * sigma ** 2))
        G_kernel /= G_kernel.sum()

        # Faltung
        rho_input = rho.unsqueeze(0).unsqueeze(0)
        kernel = G_kernel.unsqueeze(0).unsqueeze(0)
        V = F.conv2d(rho_input, kernel, padding=s_pix // 2)
        V = V[0, 0] / (4 * torch.pi * epsilon0_nm)  # Volt

        return V

    def solve_potential(self,iterations=100):
        V = torch.zeros_like(self.potential)  # initial guess
        for _ in range(iterations):
            V = 0.25 * (F.pad(V, (1, 1, 1, 1), mode='replicate')[:, :-2, 1:-1] +
                        F.pad(V, (1, 1, 1, 1), mode='replicate')[:, 2:, 1:-1] +
                        F.pad(V, (1, 1, 1, 1), mode='replicate')[:, 1:-1, :-2] +
                        F.pad(V, (1, 1, 1, 1), mode='replicate')[:, 1:-1, 2:] +
                        self.potential)  # simple Jacobi iteration
        return V

    def potential_2d_fft_nm(self, rho, epsilon0_nm=8.854e-21, device=None):
        """
        Berechnet 2D Potential mit FFT-Faltung (viel schneller für große Raster)

        rho: 2D-Tensor [ny,nx] in Vielfachen von e
        spacing: Pixelgröße in nm
        sigma: Glättungs-Gauss in nm
        """

        sigma = 1.e-3 * self.blur_sigma_

        e = 1.602e-19
        ny, nx = (self.W, self.H)
        spacing = self.pixel_size_m

        # Frequenzraum-Koordinaten
        y = torch.fft.fftfreq(ny, d=spacing, device=device)
        x = torch.fft.fftfreq(nx, d=spacing, device=device)
        Y, X = torch.meshgrid(y, x, indexing='ij')
        R2 = X ** 2 + Y ** 2

        # FFT von 1/sqrt(r^2 + sigma^2) in Fourierraum:
        # Für Gaussian-Kernel einfacher: F(G) = exp(-2 pi^2 sigma^2 (fx^2 + fy^2))
        G_fft = torch.exp(-2 * torch.pi ** 2 * sigma ** 2 * R2)

        # FFT des Rasters
        rho_fft = torch.fft.fft2(rho * e)

        # Faltung im Fourierraum
        V_fft = rho_fft * G_fft
        V = torch.fft.ifft2(V_fft).real / (4 * torch.pi * epsilon0_nm)

        return V